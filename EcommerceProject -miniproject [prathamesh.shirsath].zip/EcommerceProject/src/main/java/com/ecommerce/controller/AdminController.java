package com.ecommerce.controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.ecommerce.entity.Category;
import com.ecommerce.entity.OrderStatus;
import com.ecommerce.entity.Orderr;
import com.ecommerce.entity.Product;
import com.ecommerce.entity.User;
import com.ecommerce.repository.UserRepository;
import com.ecommerce.service.AdminService;
import com.ecommerce.service.CategoryService;
import com.ecommerce.service.OrderService;
import com.ecommerce.service.ProductService;
import com.ecommerce.service.UserService;

@Controller
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	private UserRepository userRepoitory;

	@Autowired
	private UserService userService;

	@Autowired
	private CategoryService categoryService;

	@Autowired
	private ProductService productService;

	@Autowired
	private AdminService adminService;

	@Autowired
	private OrderService orderService;

	@GetMapping("/profile")
	public String admin(Model model, Principal principal) {
		User admin = userService.findByEmail(principal.getName());
		model.addAttribute("admin", admin);
		long totalRegisteredUsers = userService.getTotalRegisteredUsersCount();
		model.addAttribute("totalRegisteredUsers", totalRegisteredUsers);
		long totalProducts = productService.getTotalProductCount();
		model.addAttribute("totalProducts", totalProducts);
		long totalOrders = orderService.getTotalOrderCount();
		model.addAttribute("totalOrders", totalOrders);
		long pendingCount = orderService.getPendingOrderCount();
		long confirmedCount = orderService.getConfirmedOrderCount();
		long shippedCount = orderService.getShippedOrderCount();
		long deliveredCount = orderService.getDeliveredOrderCount();
		long cancelledCount = orderService.getCancelledOrderCount();
		model.addAttribute("pendingCount", pendingCount);
		model.addAttribute("confirmedCount", confirmedCount);
		model.addAttribute("shippedCount", shippedCount);
		model.addAttribute("deliveredCount", deliveredCount);
		model.addAttribute("cancelledCount", cancelledCount);
		long customerCount = userService.getCustomerCount();
		long sellerCount = userService.getSellerCount();
		model.addAttribute("customerCount", customerCount);
		model.addAttribute("sellerCount", sellerCount);
		long categoryCount = categoryService.getCategoryCount();
		model.addAttribute("categoryCount", categoryCount);
		return "adminPage";
	}

	@GetMapping("/users")
	public String listUsers(Model model) {
		List<User> users = userService.findAll();
		model.addAttribute("users", users);
		return "userList";
	}
	@GetMapping("/categories")
	public String listCategories(Model model) {
		List<Category> categories = categoryService.getAllCategories();
		model.addAttribute("categories", categories);
		return "categoryList";
	}

	@GetMapping("/add")
	public String showCategoryForm(Model model) {
		model.addAttribute("category", new Category());
		return "addCategory";
	}

	@PostMapping("/add")
	public String addCategory(@ModelAttribute("category") Category category) {
		categoryService.saveCategory(category);
		return "redirect:/admin/categories";
	}

	@GetMapping("/edit/{id}")
	public String showEditForm(@PathVariable Long id, Model model) {
		Category category = categoryService.getCategoryById(id);
		model.addAttribute("category", category);
		return "editCategory";
	}

	@PostMapping("/edit/{id}")
	public String editCategory(@PathVariable Long id, @ModelAttribute("category") Category category) {
		categoryService.saveCategory(category);
		return "redirect:/admin/categories";
	}

	@GetMapping("/delete/{id}")
	public String deleteCategory(@PathVariable Long id) {
		categoryService.deleteCategory(id);
		return "redirect:/admin/categories";
	}

	@GetMapping("/productss")
	public String showProductList(Model model, @RequestParam(defaultValue = "0") int page) {
	    int pageSize = 3; // Number of products per page
	    Page<Product> productPage = adminService.getAllProductsPaginated(PageRequest.of(page, pageSize));
	    List<Product> products = productPage.getContent();

	    model.addAttribute("products", products);
	    model.addAttribute("currentPage", page);
	    model.addAttribute("totalPages", productPage.getTotalPages());

	    return "adminProductList";
	}


	@GetMapping("/addd")
	public String showAddProductFormm(Model model) {
		List<Category> categories = productService.getAllCategories();
		model.addAttribute("categories", categories);
		model.addAttribute("product", new Product());
		return "adminAddProduct";
	}

	@PostMapping("/addd")
	public String addProduct(@ModelAttribute("product") Product product, Model model,
			@RequestParam("resume") MultipartFile file, Principal principal) {
		try {
			String sellerEmail = principal.getName();
			User user = userService.getUserByEmail(sellerEmail);
			product.setUser(user);
			product.setFile(file.getOriginalFilename());
			File saveFile = new ClassPathResource("static/img").getFile();
			Path path = Paths.get(saveFile.getAbsolutePath() + File.separator + file.getOriginalFilename());
			Files.copy(file.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);

			System.out.println("File uploaded successfully!!!");

		} catch (IOException e) {
			e.printStackTrace();
			model.addAttribute("error", "Error processing file");
		}
		productService.saveProduct(product);

		return "redirect:/admin/productss";
	}

	@GetMapping("/editt/{id}")
	public String showEditProductFormm(@PathVariable Long id, Model model) {
		Product product = adminService.getProductById(id);
		model.addAttribute("product", product);
		List<Category> categories = productService.getAllCategories();
		model.addAttribute("categories", categories);
		return "adminEditProduct";
	}

	@PostMapping("/editt/{id}")
	public String editProduct(@PathVariable Long id, @ModelAttribute("product") Product editedProduct, Model model,
			@RequestParam("resume") MultipartFile file) {
		try {
			editedProduct.setFile(file.getOriginalFilename());
			File saveFile = new ClassPathResource("static/img").getFile();

			Path path = Paths.get(saveFile.getAbsolutePath() + File.separator + file.getOriginalFilename());
			Files.copy(file.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);
			System.out.println("File uploaded successfully!!!");

		} catch (IOException e) {
			e.printStackTrace();
			model.addAttribute("error", "Error processing file");
		}
		Product existingProduct = productService.getProductById(id);
		existingProduct.setName(editedProduct.getName());
		existingProduct.setDescription(editedProduct.getDescription());
		existingProduct.setPrice(editedProduct.getPrice());
		existingProduct.setFile(editedProduct.getFile());
		existingProduct.setCategory(editedProduct.getCategory());
		existingProduct.setSizes(editedProduct.getSizes());
		existingProduct.setColor(editedProduct.getColor());
		existingProduct.setBrand(editedProduct.getBrand());
		existingProduct.setQuanity(editedProduct.getQuanity());
		productService.saveProduct(existingProduct);
		return "redirect:/admin/productss";
	}

	@GetMapping("/deletee/{id}")
	public String deleteProductt(@PathVariable Long id) {
		adminService.deleteProduct(id);
		return "redirect:/admin/productss";
	}

	@GetMapping("/ordersHistory")
	public String OrderHistoryy(Model model) {
		List<Orderr> allOrders = orderService.getAllOrders(); // Replace this with your actual service method
		model.addAttribute("allOrders", allOrders);
		System.out.println(allOrders);
		return "adminOrderHistory";
	}

}
