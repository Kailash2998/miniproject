package com.ecommerce.controller;

import java.security.Principal;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ecommerce.entity.Cart;
import com.ecommerce.entity.Category;
import com.ecommerce.entity.Product;
import com.ecommerce.entity.User;
import com.ecommerce.repository.UserRepository;
import com.ecommerce.service.CartService;
import com.ecommerce.service.CategoryService;
import com.ecommerce.service.ProductService;
import com.ecommerce.service.UserService;

import jakarta.servlet.http.HttpSession;

@Controller
public class HomeController {

	@Autowired
	private UserService userService;

	@Autowired
	private UserRepository userRepository;
	@Autowired

	private ProductService productService;
	@Autowired

	private CartService cartService;

	@Autowired
	private CategoryService categoryService;

	@RequestMapping("/home")
    public String home(Model model, Authentication authentication, @RequestParam("page") Optional<Integer> page) {
        int pageSize = 6; // Number of products per page
        int currentPage = page.orElse(1);
        List<Product> products = productService.findPaginated(PageRequest.of(currentPage - 1, pageSize));
        List<Category> categories = categoryService.getAllCategories();
        model.addAttribute("categories", categories);
        model.addAttribute("products", products);
        model.addAttribute("currentPage", currentPage);
        int totalPages = productService.getTotalPages(pageSize);
        model.addAttribute("totalPages", totalPages);
        boolean isAuthenticated = authentication != null && authentication.isAuthenticated();
        model.addAttribute("authenticated", isAuthenticated);
        return "homePage";
    }
	
	@PostMapping("/home/search")
	public String searchProducts(@RequestParam("query") String query, Model model, Authentication authentication) {
		List<Category> categories = categoryService.getAllCategories();
		model.addAttribute("categories", categories);
		boolean isAuthenticated = authentication != null && authentication.isAuthenticated();
		model.addAttribute("authenticated", isAuthenticated);
		List<Product> filteredProducts = productService.searchProducts(query);
		model.addAttribute("products", filteredProducts);
		return "homePage";
	}

	@RequestMapping("/contact")
	public String contact() {
		return "contact";
	}

	@GetMapping("/login")
	public String login() {
		return "loginPage";
	}

	@GetMapping("/register")
	public String register() {
		return "register";
	}

	@PostMapping("/saveUser")
	public String saveUser(@ModelAttribute User user, HttpSession session, Model m) {
		if (userService.emailExists(user.getEmail())) {
			session.setAttribute("msg", "Email already exists. Please use a different email.");
			return "redirect:/register";
		} else {
			User u = userService.saveUser(user);
			if (u != null) {
				session.setAttribute("msg", "Register Successfully !!!");
			} else {
				session.setAttribute("msg", "Something went wrong on the server !!!");
			}
		}
		return "redirect:/login";
	}

	@PostMapping("/logout")
	public String logout(HttpSession session) {
		return "redirect:/login";
	}

}
