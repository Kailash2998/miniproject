package com.ecommerce.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ecommerce.entity.Category;
import com.ecommerce.entity.Product;
import com.ecommerce.entity.User;

@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {
	List<Product> findAll();

	Product save(Product product);

	void deleteById(Long id);

	List<Product> findByCategory(Category category);

	List<Product> findByUserEmail(String email);

	@Query("SELECT p.quanity FROM Product p WHERE p.id = :productId")
	Long findStockQuantityByProductId(@Param("productId") Long productId);

	int countByUser(User user);

	@Modifying
	@Query("UPDATE Product p SET p.quanity = p.quanity - :completeQuantity WHERE p.id = :productId")
	void subtractQuantityFromProduct(@Param("productId") Long productId,
			@Param("completeQuantity") int completeQuantity);
	
	List<Product> findByNameContainingIgnoreCase(String query);
	
    Page<Product> findByUserEmail(String email, Pageable pageable);
	
	
}
