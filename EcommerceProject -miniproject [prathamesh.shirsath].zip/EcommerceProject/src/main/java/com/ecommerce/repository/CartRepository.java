package com.ecommerce.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ecommerce.entity.Cart;
import com.ecommerce.entity.Product;
import com.ecommerce.entity.User;

public interface CartRepository extends JpaRepository<Cart, Long> {

	int countByUser(User user);

	List<Cart> findByUserId(Long userId);

	List<Cart> findByUser(User user);

	Optional<Cart> findByUserAndProduct_Id(User user, Long productId);

	Optional<Cart> findByUserIdAndProductId(Long userId, Long productId);

	Cart findByCartItemId(Long cartItemId);

	List<Cart> findByUserAndStatus(User user, String status);
	
	Optional<Cart> findByUserAndProductAndStatus(User user,Product product , String status);
	Optional<Cart> findByProduct(Product product);
	
	@Query("SELECT COALESCE(SUM(c.quanity), 0) FROM Cart c WHERE c.product.id = :productId AND c.status = :status")
    int sumQuantityByProductIdAndStatus(@Param("productId") Long productId, @Param("status") String status);
	
	@Query("SELECT DISTINCT c.product.id FROM Cart c")
    List<Long> findDistinctProductIds();

}
