package com.ecommerce.repository;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ecommerce.entity.User;

@Repository
public interface UserRepository extends JpaRepository<User, Integer> {
	public User findByEmail(String email);
	boolean existsByEmail(String email);
	User save(User user);
	List<User> findAll();
	long count();
	long countByRole(String role);
}
