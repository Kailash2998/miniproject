package com.ecommerce.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.ecommerce.entity.Product;
import com.ecommerce.repository.AdminRepository;
import com.ecommerce.repository.ProductRepository;

@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	private AdminRepository adminRepository;

	@Autowired
	private ProductRepository productRepository;

	@Override
	public List<Product> getAllProducts() {
		return adminRepository.findAll();
	}

	@Override
	public Product getProductById(Long productId) {
		return adminRepository.findById(productId).orElse(null);
	}

	@Override
	public void addProduct(Product product) {
		adminRepository.save(product);
	}

	@Override
	public void editProduct(Long productId, Product updatedProduct) {
		adminRepository.save(updatedProduct);
	}

	@Override
	public void deleteProduct(Long productId) {
		adminRepository.deleteById(productId);
	}

	@Override
	public Page<Product> getAllProductsPaginated(Pageable pageable) {
		return productRepository.findAll(pageable);
	}
}
