package com.ecommerce.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.ecommerce.entity.Category;
import com.ecommerce.entity.Product;
import com.ecommerce.entity.User;
import com.ecommerce.repository.CategoryRepository;
import com.ecommerce.repository.ProductRepository;
import com.ecommerce.repository.UserRepository;

import jakarta.transaction.Transactional;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private CategoryRepository categoryRepository;

	@Autowired
	private UserRepository userRepository;

	@Override
	public List<Product> getAllProducts() {
		return productRepository.findAll();
	}

	@Override
	public Product getProductById(Long id) {
		return productRepository.findById(id).orElse(null);
	}

	@Override
	public Product saveProduct(Product product) {
		return productRepository.save(product);
	}

	@Override
	public void deleteProduct(Long id) {
		productRepository.deleteById(id);
	}

	@Override
	public List<Category> getAllCategories() {
		return categoryRepository.findAll();
	}

	@Override
	public List<Product> getProductsBySellerEmail(String sellerEmail) {
		return productRepository.findByUserEmail(sellerEmail);
	}

	@Override
	public List<Product> findAll() {
		return productRepository.findAll();
	}

	@Override
	public Optional<Product> findById(Long id) {
		return productRepository.findById(id);
	}

	public BigDecimal getProductPriceById(Long productId) {
		Optional<Product> optionalProduct = productRepository.findById(productId);
		return optionalProduct.map(Product::getPrice).orElse(BigDecimal.ZERO);
	}

	@Override
	public void deleteProductById(Long id) {
		productRepository.deleteById(id);
	}

	@Transactional
	public Long getStockQuantity(Long productId) {
		Product product = productRepository.findById(productId).orElse(null);
		if (product != null) {
			return product.getQuanity();
		} else {
			return null;
		}
	}

	@Override
	public Long getProductStockQuantity(Long productId) {
		return productRepository.findStockQuantityByProductId(productId);
	}

	@Override
	public int countProductsBySeller(User user) {
		return productRepository.countByUser(user);
	}

	@Override
	public long getTotalProductCount() {
		return productRepository.count(); // Assuming you have a count() method in your ProductRepository
	}

	@Override
	@Transactional
	public void subtractQuantityFromProduct(Long productId, int completeQuantity) {
		productRepository.subtractQuantityFromProduct(productId, completeQuantity);
	}

	@Override
	public List<Product> searchProducts(String query) {
		return productRepository.findByNameContainingIgnoreCase(query);
	}

    @Override
    public List<Product> findPaginated(Pageable pageable) {
        Page<Product> productPage = productRepository.findAll(pageable);
        return productPage.getContent();
    }

    @Override
    public int getTotalPages(int pageSize) {
        long totalProducts = productRepository.count();
        return (int) Math.ceil((double) totalProducts / pageSize);
    }
    
    @Override
    public Page<Product> getProductsBySellerEmail(String email, Pageable pageable) {
        return productRepository.findByUserEmail(email, pageable);
    }
    
    @Override
    public Page<Product> findAll(Pageable pageable) {
        return productRepository.findAll(pageable);
    }
}
