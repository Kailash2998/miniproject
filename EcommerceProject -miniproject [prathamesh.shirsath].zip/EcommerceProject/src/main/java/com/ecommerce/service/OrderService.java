package com.ecommerce.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.ecommerce.entity.OrderStatus;
import com.ecommerce.entity.Orderr;
import com.ecommerce.entity.User;
import com.itextpdf.text.DocumentException;

public interface OrderService {

	 Orderr saveOrder(Orderr order);
	 List<Orderr> getAllOrders();
	 void cancelOrder(Long orderId);
	 Orderr getOrderById(Long orderId);
	 byte[] generateInvoiceByOrder(Long orderId) throws DocumentException;
	 List<Orderr> getOrdersBySeller(User seller);
	 long getTotalOrderCount();
	 long getPendingOrderCount();
	 long getConfirmedOrderCount();
	 long getShippedOrderCount();
	 long getDeliveredOrderCount();
	 long getCancelledOrderCount();
	 List<Orderr> getOrdersByStatus(OrderStatus status);
	 Page<Orderr> getOrdersBySeller(String email, Pageable pageable);
}
