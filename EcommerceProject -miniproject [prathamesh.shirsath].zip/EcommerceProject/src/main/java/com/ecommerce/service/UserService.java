package com.ecommerce.service;

import java.util.List;

import com.ecommerce.entity.Product;
import com.ecommerce.entity.User;

public interface UserService {

	User saveUser(User user);

	boolean emailExists(String email);

	public void removeSessionMessage();

	List<User> findAll();

	User findByEmail(String email);

	public User getUserByEmail(String email);

	long getTotalRegisteredUsersCount();

	long getCustomerCount();

	long getSellerCount();
}
