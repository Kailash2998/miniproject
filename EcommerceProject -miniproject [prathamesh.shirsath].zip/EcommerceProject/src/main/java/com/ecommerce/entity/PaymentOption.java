package com.ecommerce.entity;

public enum PaymentOption {
    GOOGLE_PAY, PHONE_PE, CREDIT_CARD
}
