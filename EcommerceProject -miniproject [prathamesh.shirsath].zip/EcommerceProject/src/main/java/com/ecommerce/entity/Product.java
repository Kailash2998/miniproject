package com.ecommerce.entity;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

@Entity
public class Product {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String name;
	private String description;
	private BigDecimal price;
	private String file;
	
	
	private Long quanity;
	private String brand;

	@ManyToOne
	@JoinColumn(name = "category_id", nullable = false)
	private Category category;

	@ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE})
	@JoinColumn(name = "user_id", nullable = false)
	private User user;

	@OneToMany(mappedBy = "product", cascade = CascadeType.ALL)
	private List<Cart> carts = new ArrayList<>();
	
	@ElementCollection(fetch = FetchType.EAGER)
    @JoinTable(
        name = "product_sizes",
        joinColumns = @JoinColumn(name = "product_id")
    )
    @Column(name = "size")
    private List<String> sizes;
	
	@ElementCollection(fetch = FetchType.EAGER)
    @JoinTable(
        name = "product_colors",
        joinColumns = @JoinColumn(name = "product_id")
    )
    @Column(name = "color")
    private List<String> color;
	
	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", description=" + description + ", price=" + price + ", file="
				+ file + ", color=" + color + ", quanity=" + quanity + ", brand=" + brand + ", category=" + category
				+ ", sizes=" + sizes + "]";
	}

	

	public List<String> getSizes() {
		return sizes;
	}

	public void setSizes(List<String> sizes) {
		this.sizes = sizes;
	}

	public List<Cart> getCarts() {
		return carts;
	}

	public void setCarts(List<Cart> carts) {
		this.carts = carts;
	}



	public Product(String name, String description, BigDecimal price, String file, Long quanity, String brand,
			Category category, User user, List<Cart> carts, List<String> sizes, List<String> color) {
		super();
		this.name = name;
		this.description = description;
		this.price = price;
		this.file = file;
		this.quanity = quanity;
		this.brand = brand;
		this.category = category;
		this.user = user;
		this.carts = carts;
		this.sizes = sizes;
		this.color = color;
	}



	public List<String> getColor() {
		return color;
	}



	public void setColor(List<String> color) {
		this.color = color;
	}



	public Long getQuanity() {
		return quanity;
	}

	public void setQuanity(Long quanity) {
		this.quanity = quanity;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public String getFile() {
		return file;
	}

	public void setFile(String file) {
		this.file = file;
	}

	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
}
