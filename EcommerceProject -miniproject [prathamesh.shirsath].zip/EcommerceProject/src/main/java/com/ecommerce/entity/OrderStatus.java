package com.ecommerce.entity;

public enum OrderStatus {
	PENDING, CONFIRMED, SHIPPED, DELIVERED, CANCELLED;
}
